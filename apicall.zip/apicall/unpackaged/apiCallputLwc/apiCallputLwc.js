import { LightningElement,wire } from 'lwc';
import  hasAccess from '@salesforce/apex/apiCalloutController.hasAccess';
import  apiCall from '@salesforce/apex/apiCalloutController.apiCall';
export default class ApiCallputLwc extends LightningElement {
    isSystemAdminWithIntegrationAdmin=false;
    
    @wire(hasAccess)
    contacts({ error, data }) {
        if (data) {
            this.isSystemAdminWithIntegrationAdmin = data;
            this.error = undefined;
        }
        else if (error) {
            this.toastEvent('error',error,'error');
            this.isSystemAdminWithIntegrationAdmin = undefined;
        };
    }
    initiateTheSyncProcess9(){
        apiCall()
        .then(result => {
            this.toastEvent('Success','Syned Completed','Success');
        })
        .catch(error => {
            this.toastEvent('error',error,'error');
        });
    }
    toastEvent(title, message, variant){
        this.dispatchEvent(new ShowToastEvent({title: title,message: message, variant: variant}));
    }
}